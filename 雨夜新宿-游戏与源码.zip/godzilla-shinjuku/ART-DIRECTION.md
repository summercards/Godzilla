# 最终美术方向

以用户第二张参考图为准：粗颗粒 16 位街机像素，硬边轮廓，深蓝夜色，灰黑巨兽，青蓝背鳍和原子吐息，黄色窗灯，洋红霓虹。不减少雨、闪电、火焰、烟尘、水面倒影与战斗动态表现。场景主题保留第一关新宿，不照搬参考图中的关卡编号。

## 生成方式

使用内置 imagegen 图像生成工具，以第二张用户图作为风格与角色参考。最终生成文件复制为 `assets/godzilla-pixel.png`，保留原生透明通道。运行时通过低分辨率 Canvas 和最近邻放大统一颗粒。建筑、军队、天气和特效由游戏程序绘制。

## 最终提示词

Use case: stylized-concept. Asset: a single isolated Godzilla game sprite with TRUE TRANSPARENT alpha background. The attached image is a STYLE AND CHARACTER reference only. Create the full Godzilla creature from the reference in the EXACT SAME COARSE 16-BIT PIXEL GAME STYLE, facing right, side view. Very visible square pixel blocks, limited charcoal gray palette, simple dark chunky clusters, hard black outline, electric cyan jagged dorsal plates, tiny orange eye. Large stocky thighs, arms extended forward, roaring mouth open toward right, white teeth, thick tail curving far to the left. Entire body and full tail and both feet visible, nothing cropped. Crisp recognizable retro arcade silhouette, roughly 160x160 logical pixel detail enlarged with nearest-neighbor. No fine grain, no realistic microtexture, no smooth shading, no 3D. Genuinely transparent background, no sky, no ground, no shadow, no other objects, no laser, no text, no HUD, no border. Landscape framing fitting tail and all body with 5% margin.
